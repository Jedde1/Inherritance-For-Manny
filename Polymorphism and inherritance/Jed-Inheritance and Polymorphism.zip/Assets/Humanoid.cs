﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Humanoid : MonoBehaviour
{
    public int speed = 5;
    public int Health = 10;
    public float _gravity = 100;
    public Transform player;

    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    public virtual void Update()
    {
        
    }
}
